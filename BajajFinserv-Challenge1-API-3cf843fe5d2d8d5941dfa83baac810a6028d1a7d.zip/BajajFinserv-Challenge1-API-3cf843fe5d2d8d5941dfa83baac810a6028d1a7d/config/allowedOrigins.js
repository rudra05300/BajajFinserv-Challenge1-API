const allowedOrigins = [
    'https://bajajfinserv-challenge1.onrender.com',
]

module.exports = allowedOrigins